package com.example.assign_mobile

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.net.Uri

class AboutActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        val aboutText = findViewById<TextView>(R.id.text_about)
        aboutText.text = """
        Developer: FATIN NABIHAH BINTI SHAMSULL BAHRIN
        
        Programme: CDCS251
        
        Student ID: 2023861668
        
        Group: RCDCS2515B
        """.trimIndent()

        val aboutButton = findViewById<Button>(R.id.about_button)
        aboutButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/fatin1182/mobile-app-assignment"))
            startActivity(intent)
        }
    }
}