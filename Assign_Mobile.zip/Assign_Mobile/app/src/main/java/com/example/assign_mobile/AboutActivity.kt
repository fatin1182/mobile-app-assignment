package com.example.assign_mobile

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        val aboutText = findViewById<TextView>(R.id.text_about)
        aboutText.text = """
        Developer: FATIN NABIHAH BINTI SHAMSULL BAHRIN
        
        Programme: CDCS251
        
        Student ID: 2023861668
        
        Group: RCDCS2515B
        
        GitHub: 
        """.trimIndent()
    }
}