package com.example.assign_mobile

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.widget.*
import android.content.Intent

class MainActivity : AppCompatActivity() {
    @SuppressLint("DefaultLocale")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        supportActionBar?.title = "Electricity Estimator"

        val inputKwh = findViewById<EditText>(R.id.input_kwh)
        val inputRebate = findViewById<EditText>(R.id.input_rebate)
        val buttonCalculate = findViewById<Button>(R.id.button_calculate)
        val buttonClear = findViewById<Button>(R.id.button_clear)
        val textResult = findViewById<TextView>(R.id.text_result)
        val buttonAbout= findViewById<Button>(R.id.button_about)

        buttonCalculate.setOnClickListener{
            val kwh = inputKwh.text.toString().toDoubleOrNull()
            val rebate = inputRebate.text.toString().toDoubleOrNull()

            if(kwh == null || rebate == null || rebate < 0 || rebate > 5) {
                Toast.makeText(this, "Please enter valid inputs", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val totalCharge = calculateCost(kwh)
            val finalCost = totalCharge - (totalCharge * (rebate / 100))

            textResult.text = String.format(
                "Total Charge: RM %.2f\n\nFinal Cost (after rebate): RM %.2f", totalCharge, finalCost
            )
        }

        buttonClear.setOnClickListener{
            inputKwh.text.clear()
            inputRebate.text.clear()
            textResult.text = ""
        }

        buttonAbout.setOnClickListener {
            val intent = Intent(this, AboutActivity::class.java)
            startActivity(intent)
        }
    }
    private fun calculateCost(kwh: Double): Double{
        val block1 = 200.0
        val block2 = 100.0
        val block3 = 300.0

        val rate1 = 0.218
        val rate2 = 0.334
        val rate3 = 0.516
        val rate4 = 0.546

        return when{
            kwh <= block1 -> {
                kwh * rate1
            }
            kwh <= block1 + block2 -> {
                (block1 * rate1) + ((kwh - block1) * rate2)
            }
            kwh <= block1 + block2 + block3 -> {
                (block1 * rate1) + (block2 * rate2) + ((kwh - block1 - block2) * rate3)
            }
            else ->
                (block1 * rate1) + (block2 * rate2) + (block3 * rate3) + ((kwh - block1 - block2 - block3) * rate4)
        }
    }
}